package edu.internet2.middleware.grouper.grouperUi.beans.api;


public class GuiDeprovisioningUser {

  /**
   * membership in the deprovisioning group
   */
  private GuiMembership guiMembership;

  /**
   * membership in the deprovisioning group
   * @return the gui membership
   */
  public GuiMembership getGuiMembership() {
    return this.guiMembership;
  }

  /**
   * membership in the deprovisioning group
   * @param guiMembership2
   */
  public void setGuiMembership(GuiMembership guiMembership2) {
    this.guiMembership = guiMembership2;
  }
  
//  private Gui
  
}
