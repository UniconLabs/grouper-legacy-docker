/*******************************************************************************
 * Copyright 2014 Internet2
 *  
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *  
 *   http://www.apache.org/licenses/LICENSE-2.0
 *  
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/
/**
 * GetPermissionAssignmentsLite.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.1  Built on : Aug 31, 2011 (12:23:23 CEST)
 */

            
                package edu.internet2.middleware.grouper.ws.soap_v2_2.xsd;
            

            /**
            *  GetPermissionAssignmentsLite bean class
            */
            @SuppressWarnings({"unchecked","unused"})
        
        public  class GetPermissionAssignmentsLite
        implements org.apache.axis2.databinding.ADBBean{
        
                public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                "getPermissionAssignmentsLite",
                "ns1");

            

                        /**
                        * field for ClientVersion
                        */

                        
                                    protected java.lang.String localClientVersion ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localClientVersionTracker = false ;

                           public boolean isClientVersionSpecified(){
                               return localClientVersionTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getClientVersion(){
                               return localClientVersion;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ClientVersion
                               */
                               public void setClientVersion(java.lang.String param){
                            localClientVersionTracker = true;
                                   
                                            this.localClientVersion=param;
                                    

                               }
                            

                        /**
                        * field for WsAttributeDefName
                        */

                        
                                    protected java.lang.String localWsAttributeDefName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsAttributeDefNameTracker = false ;

                           public boolean isWsAttributeDefNameSpecified(){
                               return localWsAttributeDefNameTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsAttributeDefName(){
                               return localWsAttributeDefName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsAttributeDefName
                               */
                               public void setWsAttributeDefName(java.lang.String param){
                            localWsAttributeDefNameTracker = true;
                                   
                                            this.localWsAttributeDefName=param;
                                    

                               }
                            

                        /**
                        * field for WsAttributeDefId
                        */

                        
                                    protected java.lang.String localWsAttributeDefId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsAttributeDefIdTracker = false ;

                           public boolean isWsAttributeDefIdSpecified(){
                               return localWsAttributeDefIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsAttributeDefId(){
                               return localWsAttributeDefId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsAttributeDefId
                               */
                               public void setWsAttributeDefId(java.lang.String param){
                            localWsAttributeDefIdTracker = true;
                                   
                                            this.localWsAttributeDefId=param;
                                    

                               }
                            

                        /**
                        * field for WsAttributeDefNameName
                        */

                        
                                    protected java.lang.String localWsAttributeDefNameName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsAttributeDefNameNameTracker = false ;

                           public boolean isWsAttributeDefNameNameSpecified(){
                               return localWsAttributeDefNameNameTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsAttributeDefNameName(){
                               return localWsAttributeDefNameName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsAttributeDefNameName
                               */
                               public void setWsAttributeDefNameName(java.lang.String param){
                            localWsAttributeDefNameNameTracker = true;
                                   
                                            this.localWsAttributeDefNameName=param;
                                    

                               }
                            

                        /**
                        * field for WsAttributeDefNameId
                        */

                        
                                    protected java.lang.String localWsAttributeDefNameId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsAttributeDefNameIdTracker = false ;

                           public boolean isWsAttributeDefNameIdSpecified(){
                               return localWsAttributeDefNameIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsAttributeDefNameId(){
                               return localWsAttributeDefNameId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsAttributeDefNameId
                               */
                               public void setWsAttributeDefNameId(java.lang.String param){
                            localWsAttributeDefNameIdTracker = true;
                                   
                                            this.localWsAttributeDefNameId=param;
                                    

                               }
                            

                        /**
                        * field for RoleName
                        */

                        
                                    protected java.lang.String localRoleName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRoleNameTracker = false ;

                           public boolean isRoleNameSpecified(){
                               return localRoleNameTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRoleName(){
                               return localRoleName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RoleName
                               */
                               public void setRoleName(java.lang.String param){
                            localRoleNameTracker = true;
                                   
                                            this.localRoleName=param;
                                    

                               }
                            

                        /**
                        * field for RoleId
                        */

                        
                                    protected java.lang.String localRoleId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRoleIdTracker = false ;

                           public boolean isRoleIdSpecified(){
                               return localRoleIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRoleId(){
                               return localRoleId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RoleId
                               */
                               public void setRoleId(java.lang.String param){
                            localRoleIdTracker = true;
                                   
                                            this.localRoleId=param;
                                    

                               }
                            

                        /**
                        * field for WsSubjectId
                        */

                        
                                    protected java.lang.String localWsSubjectId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsSubjectIdTracker = false ;

                           public boolean isWsSubjectIdSpecified(){
                               return localWsSubjectIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsSubjectId(){
                               return localWsSubjectId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsSubjectId
                               */
                               public void setWsSubjectId(java.lang.String param){
                            localWsSubjectIdTracker = true;
                                   
                                            this.localWsSubjectId=param;
                                    

                               }
                            

                        /**
                        * field for WsSubjectSourceId
                        */

                        
                                    protected java.lang.String localWsSubjectSourceId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsSubjectSourceIdTracker = false ;

                           public boolean isWsSubjectSourceIdSpecified(){
                               return localWsSubjectSourceIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsSubjectSourceId(){
                               return localWsSubjectSourceId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsSubjectSourceId
                               */
                               public void setWsSubjectSourceId(java.lang.String param){
                            localWsSubjectSourceIdTracker = true;
                                   
                                            this.localWsSubjectSourceId=param;
                                    

                               }
                            

                        /**
                        * field for WsSubjectIdentifier
                        */

                        
                                    protected java.lang.String localWsSubjectIdentifier ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsSubjectIdentifierTracker = false ;

                           public boolean isWsSubjectIdentifierSpecified(){
                               return localWsSubjectIdentifierTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWsSubjectIdentifier(){
                               return localWsSubjectIdentifier;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsSubjectIdentifier
                               */
                               public void setWsSubjectIdentifier(java.lang.String param){
                            localWsSubjectIdentifierTracker = true;
                                   
                                            this.localWsSubjectIdentifier=param;
                                    

                               }
                            

                        /**
                        * field for Action
                        */

                        
                                    protected java.lang.String localAction ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActionTracker = false ;

                           public boolean isActionSpecified(){
                               return localActionTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getAction(){
                               return localAction;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Action
                               */
                               public void setAction(java.lang.String param){
                            localActionTracker = true;
                                   
                                            this.localAction=param;
                                    

                               }
                            

                        /**
                        * field for IncludePermissionAssignDetail
                        */

                        
                                    protected java.lang.String localIncludePermissionAssignDetail ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludePermissionAssignDetailTracker = false ;

                           public boolean isIncludePermissionAssignDetailSpecified(){
                               return localIncludePermissionAssignDetailTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludePermissionAssignDetail(){
                               return localIncludePermissionAssignDetail;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludePermissionAssignDetail
                               */
                               public void setIncludePermissionAssignDetail(java.lang.String param){
                            localIncludePermissionAssignDetailTracker = true;
                                   
                                            this.localIncludePermissionAssignDetail=param;
                                    

                               }
                            

                        /**
                        * field for IncludeAttributeDefNames
                        */

                        
                                    protected java.lang.String localIncludeAttributeDefNames ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludeAttributeDefNamesTracker = false ;

                           public boolean isIncludeAttributeDefNamesSpecified(){
                               return localIncludeAttributeDefNamesTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludeAttributeDefNames(){
                               return localIncludeAttributeDefNames;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludeAttributeDefNames
                               */
                               public void setIncludeAttributeDefNames(java.lang.String param){
                            localIncludeAttributeDefNamesTracker = true;
                                   
                                            this.localIncludeAttributeDefNames=param;
                                    

                               }
                            

                        /**
                        * field for IncludeAttributeAssignments
                        */

                        
                                    protected java.lang.String localIncludeAttributeAssignments ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludeAttributeAssignmentsTracker = false ;

                           public boolean isIncludeAttributeAssignmentsSpecified(){
                               return localIncludeAttributeAssignmentsTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludeAttributeAssignments(){
                               return localIncludeAttributeAssignments;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludeAttributeAssignments
                               */
                               public void setIncludeAttributeAssignments(java.lang.String param){
                            localIncludeAttributeAssignmentsTracker = true;
                                   
                                            this.localIncludeAttributeAssignments=param;
                                    

                               }
                            

                        /**
                        * field for IncludeAssignmentsOnAssignments
                        */

                        
                                    protected java.lang.String localIncludeAssignmentsOnAssignments ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludeAssignmentsOnAssignmentsTracker = false ;

                           public boolean isIncludeAssignmentsOnAssignmentsSpecified(){
                               return localIncludeAssignmentsOnAssignmentsTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludeAssignmentsOnAssignments(){
                               return localIncludeAssignmentsOnAssignments;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludeAssignmentsOnAssignments
                               */
                               public void setIncludeAssignmentsOnAssignments(java.lang.String param){
                            localIncludeAssignmentsOnAssignmentsTracker = true;
                                   
                                            this.localIncludeAssignmentsOnAssignments=param;
                                    

                               }
                            

                        /**
                        * field for ActAsSubjectId
                        */

                        
                                    protected java.lang.String localActAsSubjectId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActAsSubjectIdTracker = false ;

                           public boolean isActAsSubjectIdSpecified(){
                               return localActAsSubjectIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getActAsSubjectId(){
                               return localActAsSubjectId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ActAsSubjectId
                               */
                               public void setActAsSubjectId(java.lang.String param){
                            localActAsSubjectIdTracker = true;
                                   
                                            this.localActAsSubjectId=param;
                                    

                               }
                            

                        /**
                        * field for ActAsSubjectSourceId
                        */

                        
                                    protected java.lang.String localActAsSubjectSourceId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActAsSubjectSourceIdTracker = false ;

                           public boolean isActAsSubjectSourceIdSpecified(){
                               return localActAsSubjectSourceIdTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getActAsSubjectSourceId(){
                               return localActAsSubjectSourceId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ActAsSubjectSourceId
                               */
                               public void setActAsSubjectSourceId(java.lang.String param){
                            localActAsSubjectSourceIdTracker = true;
                                   
                                            this.localActAsSubjectSourceId=param;
                                    

                               }
                            

                        /**
                        * field for ActAsSubjectIdentifier
                        */

                        
                                    protected java.lang.String localActAsSubjectIdentifier ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActAsSubjectIdentifierTracker = false ;

                           public boolean isActAsSubjectIdentifierSpecified(){
                               return localActAsSubjectIdentifierTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getActAsSubjectIdentifier(){
                               return localActAsSubjectIdentifier;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ActAsSubjectIdentifier
                               */
                               public void setActAsSubjectIdentifier(java.lang.String param){
                            localActAsSubjectIdentifierTracker = true;
                                   
                                            this.localActAsSubjectIdentifier=param;
                                    

                               }
                            

                        /**
                        * field for IncludeSubjectDetail
                        */

                        
                                    protected java.lang.String localIncludeSubjectDetail ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludeSubjectDetailTracker = false ;

                           public boolean isIncludeSubjectDetailSpecified(){
                               return localIncludeSubjectDetailTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludeSubjectDetail(){
                               return localIncludeSubjectDetail;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludeSubjectDetail
                               */
                               public void setIncludeSubjectDetail(java.lang.String param){
                            localIncludeSubjectDetailTracker = true;
                                   
                                            this.localIncludeSubjectDetail=param;
                                    

                               }
                            

                        /**
                        * field for SubjectAttributeNames
                        */

                        
                                    protected java.lang.String localSubjectAttributeNames ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSubjectAttributeNamesTracker = false ;

                           public boolean isSubjectAttributeNamesSpecified(){
                               return localSubjectAttributeNamesTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSubjectAttributeNames(){
                               return localSubjectAttributeNames;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SubjectAttributeNames
                               */
                               public void setSubjectAttributeNames(java.lang.String param){
                            localSubjectAttributeNamesTracker = true;
                                   
                                            this.localSubjectAttributeNames=param;
                                    

                               }
                            

                        /**
                        * field for IncludeGroupDetail
                        */

                        
                                    protected java.lang.String localIncludeGroupDetail ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludeGroupDetailTracker = false ;

                           public boolean isIncludeGroupDetailSpecified(){
                               return localIncludeGroupDetailTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludeGroupDetail(){
                               return localIncludeGroupDetail;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludeGroupDetail
                               */
                               public void setIncludeGroupDetail(java.lang.String param){
                            localIncludeGroupDetailTracker = true;
                                   
                                            this.localIncludeGroupDetail=param;
                                    

                               }
                            

                        /**
                        * field for ParamName0
                        */

                        
                                    protected java.lang.String localParamName0 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localParamName0Tracker = false ;

                           public boolean isParamName0Specified(){
                               return localParamName0Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getParamName0(){
                               return localParamName0;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ParamName0
                               */
                               public void setParamName0(java.lang.String param){
                            localParamName0Tracker = true;
                                   
                                            this.localParamName0=param;
                                    

                               }
                            

                        /**
                        * field for ParamValue0
                        */

                        
                                    protected java.lang.String localParamValue0 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localParamValue0Tracker = false ;

                           public boolean isParamValue0Specified(){
                               return localParamValue0Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getParamValue0(){
                               return localParamValue0;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ParamValue0
                               */
                               public void setParamValue0(java.lang.String param){
                            localParamValue0Tracker = true;
                                   
                                            this.localParamValue0=param;
                                    

                               }
                            

                        /**
                        * field for ParamName1
                        */

                        
                                    protected java.lang.String localParamName1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localParamName1Tracker = false ;

                           public boolean isParamName1Specified(){
                               return localParamName1Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getParamName1(){
                               return localParamName1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ParamName1
                               */
                               public void setParamName1(java.lang.String param){
                            localParamName1Tracker = true;
                                   
                                            this.localParamName1=param;
                                    

                               }
                            

                        /**
                        * field for ParamValue1
                        */

                        
                                    protected java.lang.String localParamValue1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localParamValue1Tracker = false ;

                           public boolean isParamValue1Specified(){
                               return localParamValue1Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getParamValue1(){
                               return localParamValue1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ParamValue1
                               */
                               public void setParamValue1(java.lang.String param){
                            localParamValue1Tracker = true;
                                   
                                            this.localParamValue1=param;
                                    

                               }
                            

                        /**
                        * field for Enabled
                        */

                        
                                    protected java.lang.String localEnabled ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEnabledTracker = false ;

                           public boolean isEnabledSpecified(){
                               return localEnabledTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getEnabled(){
                               return localEnabled;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Enabled
                               */
                               public void setEnabled(java.lang.String param){
                            localEnabledTracker = true;
                                   
                                            this.localEnabled=param;
                                    

                               }
                            

                        /**
                        * field for PointInTimeFrom
                        */

                        
                                    protected java.lang.String localPointInTimeFrom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPointInTimeFromTracker = false ;

                           public boolean isPointInTimeFromSpecified(){
                               return localPointInTimeFromTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPointInTimeFrom(){
                               return localPointInTimeFrom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PointInTimeFrom
                               */
                               public void setPointInTimeFrom(java.lang.String param){
                            localPointInTimeFromTracker = true;
                                   
                                            this.localPointInTimeFrom=param;
                                    

                               }
                            

                        /**
                        * field for PointInTimeTo
                        */

                        
                                    protected java.lang.String localPointInTimeTo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPointInTimeToTracker = false ;

                           public boolean isPointInTimeToSpecified(){
                               return localPointInTimeToTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPointInTimeTo(){
                               return localPointInTimeTo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PointInTimeTo
                               */
                               public void setPointInTimeTo(java.lang.String param){
                            localPointInTimeToTracker = true;
                                   
                                            this.localPointInTimeTo=param;
                                    

                               }
                            

                        /**
                        * field for ImmediateOnly
                        */

                        
                                    protected java.lang.String localImmediateOnly ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localImmediateOnlyTracker = false ;

                           public boolean isImmediateOnlySpecified(){
                               return localImmediateOnlyTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getImmediateOnly(){
                               return localImmediateOnly;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ImmediateOnly
                               */
                               public void setImmediateOnly(java.lang.String param){
                            localImmediateOnlyTracker = true;
                                   
                                            this.localImmediateOnly=param;
                                    

                               }
                            

                        /**
                        * field for PermissionType
                        */

                        
                                    protected java.lang.String localPermissionType ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPermissionTypeTracker = false ;

                           public boolean isPermissionTypeSpecified(){
                               return localPermissionTypeTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPermissionType(){
                               return localPermissionType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PermissionType
                               */
                               public void setPermissionType(java.lang.String param){
                            localPermissionTypeTracker = true;
                                   
                                            this.localPermissionType=param;
                                    

                               }
                            

                        /**
                        * field for PermissionProcessor
                        */

                        
                                    protected java.lang.String localPermissionProcessor ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPermissionProcessorTracker = false ;

                           public boolean isPermissionProcessorSpecified(){
                               return localPermissionProcessorTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPermissionProcessor(){
                               return localPermissionProcessor;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PermissionProcessor
                               */
                               public void setPermissionProcessor(java.lang.String param){
                            localPermissionProcessorTracker = true;
                                   
                                            this.localPermissionProcessor=param;
                                    

                               }
                            

                        /**
                        * field for LimitEnvVarName0
                        */

                        
                                    protected java.lang.String localLimitEnvVarName0 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLimitEnvVarName0Tracker = false ;

                           public boolean isLimitEnvVarName0Specified(){
                               return localLimitEnvVarName0Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLimitEnvVarName0(){
                               return localLimitEnvVarName0;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LimitEnvVarName0
                               */
                               public void setLimitEnvVarName0(java.lang.String param){
                            localLimitEnvVarName0Tracker = true;
                                   
                                            this.localLimitEnvVarName0=param;
                                    

                               }
                            

                        /**
                        * field for LimitEnvVarValue0
                        */

                        
                                    protected java.lang.String localLimitEnvVarValue0 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLimitEnvVarValue0Tracker = false ;

                           public boolean isLimitEnvVarValue0Specified(){
                               return localLimitEnvVarValue0Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLimitEnvVarValue0(){
                               return localLimitEnvVarValue0;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LimitEnvVarValue0
                               */
                               public void setLimitEnvVarValue0(java.lang.String param){
                            localLimitEnvVarValue0Tracker = true;
                                   
                                            this.localLimitEnvVarValue0=param;
                                    

                               }
                            

                        /**
                        * field for LimitEnvVarType0
                        */

                        
                                    protected java.lang.String localLimitEnvVarType0 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLimitEnvVarType0Tracker = false ;

                           public boolean isLimitEnvVarType0Specified(){
                               return localLimitEnvVarType0Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLimitEnvVarType0(){
                               return localLimitEnvVarType0;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LimitEnvVarType0
                               */
                               public void setLimitEnvVarType0(java.lang.String param){
                            localLimitEnvVarType0Tracker = true;
                                   
                                            this.localLimitEnvVarType0=param;
                                    

                               }
                            

                        /**
                        * field for LimitEnvVarName1
                        */

                        
                                    protected java.lang.String localLimitEnvVarName1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLimitEnvVarName1Tracker = false ;

                           public boolean isLimitEnvVarName1Specified(){
                               return localLimitEnvVarName1Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLimitEnvVarName1(){
                               return localLimitEnvVarName1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LimitEnvVarName1
                               */
                               public void setLimitEnvVarName1(java.lang.String param){
                            localLimitEnvVarName1Tracker = true;
                                   
                                            this.localLimitEnvVarName1=param;
                                    

                               }
                            

                        /**
                        * field for LimitEnvVarValue1
                        */

                        
                                    protected java.lang.String localLimitEnvVarValue1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLimitEnvVarValue1Tracker = false ;

                           public boolean isLimitEnvVarValue1Specified(){
                               return localLimitEnvVarValue1Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLimitEnvVarValue1(){
                               return localLimitEnvVarValue1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LimitEnvVarValue1
                               */
                               public void setLimitEnvVarValue1(java.lang.String param){
                            localLimitEnvVarValue1Tracker = true;
                                   
                                            this.localLimitEnvVarValue1=param;
                                    

                               }
                            

                        /**
                        * field for LimitEnvVarType1
                        */

                        
                                    protected java.lang.String localLimitEnvVarType1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLimitEnvVarType1Tracker = false ;

                           public boolean isLimitEnvVarType1Specified(){
                               return localLimitEnvVarType1Tracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLimitEnvVarType1(){
                               return localLimitEnvVarType1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LimitEnvVarType1
                               */
                               public void setLimitEnvVarType1(java.lang.String param){
                            localLimitEnvVarType1Tracker = true;
                                   
                                            this.localLimitEnvVarType1=param;
                                    

                               }
                            

                        /**
                        * field for IncludeLimits
                        */

                        
                                    protected java.lang.String localIncludeLimits ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncludeLimitsTracker = false ;

                           public boolean isIncludeLimitsSpecified(){
                               return localIncludeLimitsTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncludeLimits(){
                               return localIncludeLimits;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncludeLimits
                               */
                               public void setIncludeLimits(java.lang.String param){
                            localIncludeLimitsTracker = true;
                                   
                                            this.localIncludeLimits=param;
                                    

                               }
                            

     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,MY_QNAME);
               return factory.createOMElement(dataSource,MY_QNAME);
            
        }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       javax.xml.stream.XMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               javax.xml.stream.XMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();
                    writeStartElement(prefix, namespace, parentQName.getLocalPart(), xmlWriter);
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":getPermissionAssignmentsLite",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "getPermissionAssignmentsLite",
                           xmlWriter);
                   }

               
                   }
                if (localClientVersionTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "clientVersion", xmlWriter);
                             

                                          if (localClientVersion==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localClientVersion);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsAttributeDefNameTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsAttributeDefName", xmlWriter);
                             

                                          if (localWsAttributeDefName==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsAttributeDefName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsAttributeDefIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsAttributeDefId", xmlWriter);
                             

                                          if (localWsAttributeDefId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsAttributeDefId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsAttributeDefNameNameTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsAttributeDefNameName", xmlWriter);
                             

                                          if (localWsAttributeDefNameName==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsAttributeDefNameName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsAttributeDefNameIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsAttributeDefNameId", xmlWriter);
                             

                                          if (localWsAttributeDefNameId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsAttributeDefNameId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRoleNameTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "roleName", xmlWriter);
                             

                                          if (localRoleName==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRoleName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRoleIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "roleId", xmlWriter);
                             

                                          if (localRoleId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRoleId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsSubjectIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsSubjectId", xmlWriter);
                             

                                          if (localWsSubjectId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsSubjectId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsSubjectSourceIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsSubjectSourceId", xmlWriter);
                             

                                          if (localWsSubjectSourceId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsSubjectSourceId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsSubjectIdentifierTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "wsSubjectIdentifier", xmlWriter);
                             

                                          if (localWsSubjectIdentifier==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWsSubjectIdentifier);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActionTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "action", xmlWriter);
                             

                                          if (localAction==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localAction);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludePermissionAssignDetailTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includePermissionAssignDetail", xmlWriter);
                             

                                          if (localIncludePermissionAssignDetail==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludePermissionAssignDetail);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludeAttributeDefNamesTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includeAttributeDefNames", xmlWriter);
                             

                                          if (localIncludeAttributeDefNames==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludeAttributeDefNames);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludeAttributeAssignmentsTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includeAttributeAssignments", xmlWriter);
                             

                                          if (localIncludeAttributeAssignments==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludeAttributeAssignments);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludeAssignmentsOnAssignmentsTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includeAssignmentsOnAssignments", xmlWriter);
                             

                                          if (localIncludeAssignmentsOnAssignments==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludeAssignmentsOnAssignments);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActAsSubjectIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "actAsSubjectId", xmlWriter);
                             

                                          if (localActAsSubjectId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localActAsSubjectId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActAsSubjectSourceIdTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "actAsSubjectSourceId", xmlWriter);
                             

                                          if (localActAsSubjectSourceId==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localActAsSubjectSourceId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActAsSubjectIdentifierTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "actAsSubjectIdentifier", xmlWriter);
                             

                                          if (localActAsSubjectIdentifier==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localActAsSubjectIdentifier);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludeSubjectDetailTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includeSubjectDetail", xmlWriter);
                             

                                          if (localIncludeSubjectDetail==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludeSubjectDetail);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSubjectAttributeNamesTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "subjectAttributeNames", xmlWriter);
                             

                                          if (localSubjectAttributeNames==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSubjectAttributeNames);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludeGroupDetailTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includeGroupDetail", xmlWriter);
                             

                                          if (localIncludeGroupDetail==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludeGroupDetail);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localParamName0Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "paramName0", xmlWriter);
                             

                                          if (localParamName0==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localParamName0);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localParamValue0Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "paramValue0", xmlWriter);
                             

                                          if (localParamValue0==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localParamValue0);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localParamName1Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "paramName1", xmlWriter);
                             

                                          if (localParamName1==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localParamName1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localParamValue1Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "paramValue1", xmlWriter);
                             

                                          if (localParamValue1==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localParamValue1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEnabledTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "enabled", xmlWriter);
                             

                                          if (localEnabled==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localEnabled);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPointInTimeFromTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "pointInTimeFrom", xmlWriter);
                             

                                          if (localPointInTimeFrom==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPointInTimeFrom);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPointInTimeToTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "pointInTimeTo", xmlWriter);
                             

                                          if (localPointInTimeTo==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPointInTimeTo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localImmediateOnlyTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "immediateOnly", xmlWriter);
                             

                                          if (localImmediateOnly==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localImmediateOnly);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPermissionTypeTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "permissionType", xmlWriter);
                             

                                          if (localPermissionType==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPermissionType);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPermissionProcessorTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "permissionProcessor", xmlWriter);
                             

                                          if (localPermissionProcessor==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPermissionProcessor);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLimitEnvVarName0Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "limitEnvVarName0", xmlWriter);
                             

                                          if (localLimitEnvVarName0==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLimitEnvVarName0);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLimitEnvVarValue0Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "limitEnvVarValue0", xmlWriter);
                             

                                          if (localLimitEnvVarValue0==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLimitEnvVarValue0);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLimitEnvVarType0Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "limitEnvVarType0", xmlWriter);
                             

                                          if (localLimitEnvVarType0==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLimitEnvVarType0);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLimitEnvVarName1Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "limitEnvVarName1", xmlWriter);
                             

                                          if (localLimitEnvVarName1==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLimitEnvVarName1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLimitEnvVarValue1Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "limitEnvVarValue1", xmlWriter);
                             

                                          if (localLimitEnvVarValue1==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLimitEnvVarValue1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLimitEnvVarType1Tracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "limitEnvVarType1", xmlWriter);
                             

                                          if (localLimitEnvVarType1==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLimitEnvVarType1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncludeLimitsTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "includeLimits", xmlWriter);
                             

                                          if (localIncludeLimits==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncludeLimits);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * Utility method to write an element start tag.
         */
        private void writeStartElement(java.lang.String prefix, java.lang.String namespace, java.lang.String localPart,
                                       javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace, localPart);
            } else {
                if (namespace.length() == 0) {
                    prefix = "";
                } else if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, localPart, namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        }
        
        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                    java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
            if (xmlWriter.getPrefix(namespace) == null) {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
            xmlWriter.writeAttribute(namespace,attName,attValue);
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                    java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
            if (namespace.equals("")) {
                xmlWriter.writeAttribute(attName,attValue);
            } else {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace,attName,attValue);
            }
        }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);
            if (prefix == null) {
                prefix = generatePrefix(namespace);
                javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();
                while (true) {
                    java.lang.String uri = nsContext.getNamespaceURI(prefix);
                    if (uri == null || uri.length() == 0) {
                        break;
                    }
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
            return prefix;
        }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localClientVersionTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "clientVersion"));
                                 
                                         elementList.add(localClientVersion==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localClientVersion));
                                    } if (localWsAttributeDefNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsAttributeDefName"));
                                 
                                         elementList.add(localWsAttributeDefName==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsAttributeDefName));
                                    } if (localWsAttributeDefIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsAttributeDefId"));
                                 
                                         elementList.add(localWsAttributeDefId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsAttributeDefId));
                                    } if (localWsAttributeDefNameNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsAttributeDefNameName"));
                                 
                                         elementList.add(localWsAttributeDefNameName==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsAttributeDefNameName));
                                    } if (localWsAttributeDefNameIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsAttributeDefNameId"));
                                 
                                         elementList.add(localWsAttributeDefNameId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsAttributeDefNameId));
                                    } if (localRoleNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "roleName"));
                                 
                                         elementList.add(localRoleName==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRoleName));
                                    } if (localRoleIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "roleId"));
                                 
                                         elementList.add(localRoleId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRoleId));
                                    } if (localWsSubjectIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsSubjectId"));
                                 
                                         elementList.add(localWsSubjectId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsSubjectId));
                                    } if (localWsSubjectSourceIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsSubjectSourceId"));
                                 
                                         elementList.add(localWsSubjectSourceId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsSubjectSourceId));
                                    } if (localWsSubjectIdentifierTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsSubjectIdentifier"));
                                 
                                         elementList.add(localWsSubjectIdentifier==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWsSubjectIdentifier));
                                    } if (localActionTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "action"));
                                 
                                         elementList.add(localAction==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localAction));
                                    } if (localIncludePermissionAssignDetailTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includePermissionAssignDetail"));
                                 
                                         elementList.add(localIncludePermissionAssignDetail==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludePermissionAssignDetail));
                                    } if (localIncludeAttributeDefNamesTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includeAttributeDefNames"));
                                 
                                         elementList.add(localIncludeAttributeDefNames==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludeAttributeDefNames));
                                    } if (localIncludeAttributeAssignmentsTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includeAttributeAssignments"));
                                 
                                         elementList.add(localIncludeAttributeAssignments==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludeAttributeAssignments));
                                    } if (localIncludeAssignmentsOnAssignmentsTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includeAssignmentsOnAssignments"));
                                 
                                         elementList.add(localIncludeAssignmentsOnAssignments==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludeAssignmentsOnAssignments));
                                    } if (localActAsSubjectIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "actAsSubjectId"));
                                 
                                         elementList.add(localActAsSubjectId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActAsSubjectId));
                                    } if (localActAsSubjectSourceIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "actAsSubjectSourceId"));
                                 
                                         elementList.add(localActAsSubjectSourceId==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActAsSubjectSourceId));
                                    } if (localActAsSubjectIdentifierTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "actAsSubjectIdentifier"));
                                 
                                         elementList.add(localActAsSubjectIdentifier==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActAsSubjectIdentifier));
                                    } if (localIncludeSubjectDetailTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includeSubjectDetail"));
                                 
                                         elementList.add(localIncludeSubjectDetail==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludeSubjectDetail));
                                    } if (localSubjectAttributeNamesTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "subjectAttributeNames"));
                                 
                                         elementList.add(localSubjectAttributeNames==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSubjectAttributeNames));
                                    } if (localIncludeGroupDetailTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includeGroupDetail"));
                                 
                                         elementList.add(localIncludeGroupDetail==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludeGroupDetail));
                                    } if (localParamName0Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "paramName0"));
                                 
                                         elementList.add(localParamName0==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localParamName0));
                                    } if (localParamValue0Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "paramValue0"));
                                 
                                         elementList.add(localParamValue0==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localParamValue0));
                                    } if (localParamName1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "paramName1"));
                                 
                                         elementList.add(localParamName1==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localParamName1));
                                    } if (localParamValue1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "paramValue1"));
                                 
                                         elementList.add(localParamValue1==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localParamValue1));
                                    } if (localEnabledTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "enabled"));
                                 
                                         elementList.add(localEnabled==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEnabled));
                                    } if (localPointInTimeFromTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "pointInTimeFrom"));
                                 
                                         elementList.add(localPointInTimeFrom==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPointInTimeFrom));
                                    } if (localPointInTimeToTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "pointInTimeTo"));
                                 
                                         elementList.add(localPointInTimeTo==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPointInTimeTo));
                                    } if (localImmediateOnlyTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "immediateOnly"));
                                 
                                         elementList.add(localImmediateOnly==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localImmediateOnly));
                                    } if (localPermissionTypeTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "permissionType"));
                                 
                                         elementList.add(localPermissionType==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPermissionType));
                                    } if (localPermissionProcessorTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "permissionProcessor"));
                                 
                                         elementList.add(localPermissionProcessor==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPermissionProcessor));
                                    } if (localLimitEnvVarName0Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "limitEnvVarName0"));
                                 
                                         elementList.add(localLimitEnvVarName0==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLimitEnvVarName0));
                                    } if (localLimitEnvVarValue0Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "limitEnvVarValue0"));
                                 
                                         elementList.add(localLimitEnvVarValue0==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLimitEnvVarValue0));
                                    } if (localLimitEnvVarType0Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "limitEnvVarType0"));
                                 
                                         elementList.add(localLimitEnvVarType0==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLimitEnvVarType0));
                                    } if (localLimitEnvVarName1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "limitEnvVarName1"));
                                 
                                         elementList.add(localLimitEnvVarName1==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLimitEnvVarName1));
                                    } if (localLimitEnvVarValue1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "limitEnvVarValue1"));
                                 
                                         elementList.add(localLimitEnvVarValue1==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLimitEnvVarValue1));
                                    } if (localLimitEnvVarType1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "limitEnvVarType1"));
                                 
                                         elementList.add(localLimitEnvVarType1==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLimitEnvVarType1));
                                    } if (localIncludeLimitsTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "includeLimits"));
                                 
                                         elementList.add(localIncludeLimits==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncludeLimits));
                                    }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static GetPermissionAssignmentsLite parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            GetPermissionAssignmentsLite object =
                new GetPermissionAssignmentsLite();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"getPermissionAssignmentsLite".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (GetPermissionAssignmentsLite)edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","clientVersion").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setClientVersion(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsAttributeDefName").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsAttributeDefName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsAttributeDefId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsAttributeDefId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsAttributeDefNameName").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsAttributeDefNameName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsAttributeDefNameId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsAttributeDefNameId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","roleName").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRoleName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","roleId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRoleId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsSubjectId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsSubjectId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsSubjectSourceId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsSubjectSourceId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsSubjectIdentifier").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWsSubjectIdentifier(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","action").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setAction(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includePermissionAssignDetail").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludePermissionAssignDetail(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includeAttributeDefNames").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludeAttributeDefNames(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includeAttributeAssignments").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludeAttributeAssignments(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includeAssignmentsOnAssignments").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludeAssignmentsOnAssignments(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","actAsSubjectId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setActAsSubjectId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","actAsSubjectSourceId").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setActAsSubjectSourceId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","actAsSubjectIdentifier").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setActAsSubjectIdentifier(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includeSubjectDetail").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludeSubjectDetail(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","subjectAttributeNames").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSubjectAttributeNames(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includeGroupDetail").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludeGroupDetail(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","paramName0").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setParamName0(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","paramValue0").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setParamValue0(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","paramName1").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setParamName1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","paramValue1").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setParamValue1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","enabled").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEnabled(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","pointInTimeFrom").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPointInTimeFrom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","pointInTimeTo").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPointInTimeTo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","immediateOnly").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setImmediateOnly(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","permissionType").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPermissionType(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","permissionProcessor").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPermissionProcessor(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","limitEnvVarName0").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLimitEnvVarName0(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","limitEnvVarValue0").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLimitEnvVarValue0(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","limitEnvVarType0").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLimitEnvVarType0(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","limitEnvVarName1").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLimitEnvVarName1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","limitEnvVarValue1").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLimitEnvVarValue1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","limitEnvVarType1").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLimitEnvVarType1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","includeLimits").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncludeLimits(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
    
