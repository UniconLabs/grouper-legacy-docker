/*******************************************************************************
 * Copyright 2014 Internet2
 *  
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *  
 *   http://www.apache.org/licenses/LICENSE-2.0
 *  
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/
/**
 * WsGrouperPrivilegeResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.1  Built on : Aug 31, 2011 (12:23:23 CEST)
 */

            
                package edu.internet2.middleware.grouper.ws.soap_v2_2.xsd;
            

            /**
            *  WsGrouperPrivilegeResult bean class
            */
            @SuppressWarnings({"unchecked","unused"})
        
        public  class WsGrouperPrivilegeResult
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = WsGrouperPrivilegeResult
                Namespace URI = http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd
                Namespace Prefix = ns1
                */
            

                        /**
                        * field for Allowed
                        */

                        
                                    protected java.lang.String localAllowed ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localAllowedTracker = false ;

                           public boolean isAllowedSpecified(){
                               return localAllowedTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getAllowed(){
                               return localAllowed;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Allowed
                               */
                               public void setAllowed(java.lang.String param){
                            localAllowedTracker = true;
                                   
                                            this.localAllowed=param;
                                    

                               }
                            

                        /**
                        * field for OwnerSubject
                        */

                        
                                    protected edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject localOwnerSubject ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOwnerSubjectTracker = false ;

                           public boolean isOwnerSubjectSpecified(){
                               return localOwnerSubjectTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject
                           */
                           public  edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject getOwnerSubject(){
                               return localOwnerSubject;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OwnerSubject
                               */
                               public void setOwnerSubject(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject param){
                            localOwnerSubjectTracker = true;
                                   
                                            this.localOwnerSubject=param;
                                    

                               }
                            

                        /**
                        * field for PrivilegeName
                        */

                        
                                    protected java.lang.String localPrivilegeName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPrivilegeNameTracker = false ;

                           public boolean isPrivilegeNameSpecified(){
                               return localPrivilegeNameTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPrivilegeName(){
                               return localPrivilegeName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PrivilegeName
                               */
                               public void setPrivilegeName(java.lang.String param){
                            localPrivilegeNameTracker = true;
                                   
                                            this.localPrivilegeName=param;
                                    

                               }
                            

                        /**
                        * field for PrivilegeType
                        */

                        
                                    protected java.lang.String localPrivilegeType ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPrivilegeTypeTracker = false ;

                           public boolean isPrivilegeTypeSpecified(){
                               return localPrivilegeTypeTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPrivilegeType(){
                               return localPrivilegeType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PrivilegeType
                               */
                               public void setPrivilegeType(java.lang.String param){
                            localPrivilegeTypeTracker = true;
                                   
                                            this.localPrivilegeType=param;
                                    

                               }
                            

                        /**
                        * field for Revokable
                        */

                        
                                    protected java.lang.String localRevokable ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRevokableTracker = false ;

                           public boolean isRevokableSpecified(){
                               return localRevokableTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRevokable(){
                               return localRevokable;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Revokable
                               */
                               public void setRevokable(java.lang.String param){
                            localRevokableTracker = true;
                                   
                                            this.localRevokable=param;
                                    

                               }
                            

                        /**
                        * field for WsGroup
                        */

                        
                                    protected edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsGroup localWsGroup ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsGroupTracker = false ;

                           public boolean isWsGroupSpecified(){
                               return localWsGroupTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsGroup
                           */
                           public  edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsGroup getWsGroup(){
                               return localWsGroup;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsGroup
                               */
                               public void setWsGroup(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsGroup param){
                            localWsGroupTracker = true;
                                   
                                            this.localWsGroup=param;
                                    

                               }
                            

                        /**
                        * field for WsStem
                        */

                        
                                    protected edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsStem localWsStem ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsStemTracker = false ;

                           public boolean isWsStemSpecified(){
                               return localWsStemTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsStem
                           */
                           public  edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsStem getWsStem(){
                               return localWsStem;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsStem
                               */
                               public void setWsStem(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsStem param){
                            localWsStemTracker = true;
                                   
                                            this.localWsStem=param;
                                    

                               }
                            

                        /**
                        * field for WsSubject
                        */

                        
                                    protected edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject localWsSubject ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWsSubjectTracker = false ;

                           public boolean isWsSubjectSpecified(){
                               return localWsSubjectTracker;
                           }

                           

                           /**
                           * Auto generated getter method
                           * @return edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject
                           */
                           public  edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject getWsSubject(){
                               return localWsSubject;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WsSubject
                               */
                               public void setWsSubject(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject param){
                            localWsSubjectTracker = true;
                                   
                                            this.localWsSubject=param;
                                    

                               }
                            

     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName);
               return factory.createOMElement(dataSource,parentQName);
            
        }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       javax.xml.stream.XMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               javax.xml.stream.XMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();
                    writeStartElement(prefix, namespace, parentQName.getLocalPart(), xmlWriter);
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":WsGrouperPrivilegeResult",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "WsGrouperPrivilegeResult",
                           xmlWriter);
                   }

               
                   }
                if (localAllowedTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "allowed", xmlWriter);
                             

                                          if (localAllowed==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localAllowed);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOwnerSubjectTracker){
                                    if (localOwnerSubject==null){

                                        writeStartElement(null, "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd", "ownerSubject", xmlWriter);

                                       // write the nil attribute
                                      writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                      xmlWriter.writeEndElement();
                                    }else{
                                     localOwnerSubject.serialize(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","ownerSubject"),
                                        xmlWriter);
                                    }
                                } if (localPrivilegeNameTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "privilegeName", xmlWriter);
                             

                                          if (localPrivilegeName==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPrivilegeName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPrivilegeTypeTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "privilegeType", xmlWriter);
                             

                                          if (localPrivilegeType==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPrivilegeType);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRevokableTracker){
                                    namespace = "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd";
                                    writeStartElement(null, namespace, "revokable", xmlWriter);
                             

                                          if (localRevokable==null){
                                              // write the nil attribute
                                              
                                                     writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRevokable);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWsGroupTracker){
                                    if (localWsGroup==null){

                                        writeStartElement(null, "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd", "wsGroup", xmlWriter);

                                       // write the nil attribute
                                      writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                      xmlWriter.writeEndElement();
                                    }else{
                                     localWsGroup.serialize(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsGroup"),
                                        xmlWriter);
                                    }
                                } if (localWsStemTracker){
                                    if (localWsStem==null){

                                        writeStartElement(null, "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd", "wsStem", xmlWriter);

                                       // write the nil attribute
                                      writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                      xmlWriter.writeEndElement();
                                    }else{
                                     localWsStem.serialize(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsStem"),
                                        xmlWriter);
                                    }
                                } if (localWsSubjectTracker){
                                    if (localWsSubject==null){

                                        writeStartElement(null, "http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd", "wsSubject", xmlWriter);

                                       // write the nil attribute
                                      writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                      xmlWriter.writeEndElement();
                                    }else{
                                     localWsSubject.serialize(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsSubject"),
                                        xmlWriter);
                                    }
                                }
                    xmlWriter.writeEndElement();
               

        }

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * Utility method to write an element start tag.
         */
        private void writeStartElement(java.lang.String prefix, java.lang.String namespace, java.lang.String localPart,
                                       javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
            if (writerPrefix != null) {
                xmlWriter.writeStartElement(namespace, localPart);
            } else {
                if (namespace.length() == 0) {
                    prefix = "";
                } else if (prefix == null) {
                    prefix = generatePrefix(namespace);
                }

                xmlWriter.writeStartElement(prefix, localPart, namespace);
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
        }
        
        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                    java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
            if (xmlWriter.getPrefix(namespace) == null) {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
            xmlWriter.writeAttribute(namespace,attName,attValue);
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                    java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
            if (namespace.equals("")) {
                xmlWriter.writeAttribute(attName,attValue);
            } else {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace,attName,attValue);
            }
        }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);
            if (prefix == null) {
                prefix = generatePrefix(namespace);
                javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();
                while (true) {
                    java.lang.String uri = nsContext.getNamespaceURI(prefix);
                    if (uri == null || uri.length() == 0) {
                        break;
                    }
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }
            return prefix;
        }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localAllowedTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "allowed"));
                                 
                                         elementList.add(localAllowed==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localAllowed));
                                    } if (localOwnerSubjectTracker){
                            elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "ownerSubject"));
                            
                            
                                    elementList.add(localOwnerSubject==null?null:
                                    localOwnerSubject);
                                } if (localPrivilegeNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "privilegeName"));
                                 
                                         elementList.add(localPrivilegeName==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPrivilegeName));
                                    } if (localPrivilegeTypeTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "privilegeType"));
                                 
                                         elementList.add(localPrivilegeType==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPrivilegeType));
                                    } if (localRevokableTracker){
                                      elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "revokable"));
                                 
                                         elementList.add(localRevokable==null?null:
                                         org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRevokable));
                                    } if (localWsGroupTracker){
                            elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsGroup"));
                            
                            
                                    elementList.add(localWsGroup==null?null:
                                    localWsGroup);
                                } if (localWsStemTracker){
                            elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsStem"));
                            
                            
                                    elementList.add(localWsStem==null?null:
                                    localWsStem);
                                } if (localWsSubjectTracker){
                            elementList.add(new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd",
                                                                      "wsSubject"));
                            
                            
                                    elementList.add(localWsSubject==null?null:
                                    localWsSubject);
                                }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static WsGrouperPrivilegeResult parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            WsGrouperPrivilegeResult object =
                new WsGrouperPrivilegeResult();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"WsGrouperPrivilegeResult".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (WsGrouperPrivilegeResult)edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","allowed").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setAllowed(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","ownerSubject").equals(reader.getName())){
                                
                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                          object.setOwnerSubject(null);
                                          reader.next();
                                            
                                            reader.next();
                                          
                                      }else{
                                    
                                                object.setOwnerSubject(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject.Factory.parse(reader));
                                              
                                        reader.next();
                                    }
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","privilegeName").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPrivilegeName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","privilegeType").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPrivilegeType(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","revokable").equals(reader.getName())){
                                
                                       nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                       if (!"true".equals(nillableValue) && !"1".equals(nillableValue)){
                                    
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRevokable(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                            
                                       } else {
                                           
                                           
                                           reader.getElementText(); // throw away text nodes if any.
                                       }
                                      
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsGroup").equals(reader.getName())){
                                
                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                          object.setWsGroup(null);
                                          reader.next();
                                            
                                            reader.next();
                                          
                                      }else{
                                    
                                                object.setWsGroup(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsGroup.Factory.parse(reader));
                                              
                                        reader.next();
                                    }
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsStem").equals(reader.getName())){
                                
                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                          object.setWsStem(null);
                                          reader.next();
                                            
                                            reader.next();
                                          
                                      }else{
                                    
                                                object.setWsStem(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsStem.Factory.parse(reader));
                                              
                                        reader.next();
                                    }
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://soap_v2_2.ws.grouper.middleware.internet2.edu/xsd","wsSubject").equals(reader.getName())){
                                
                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                          object.setWsSubject(null);
                                          reader.next();
                                            
                                            reader.next();
                                          
                                      }else{
                                    
                                                object.setWsSubject(edu.internet2.middleware.grouper.ws.soap_v2_2.xsd.WsSubject.Factory.parse(reader));
                                              
                                        reader.next();
                                    }
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
    
