Grouper installer:

- Here is information on grouperInstaller:

https://spaces.internet2.edu/display/Grouper/Grouper+Installer

- Generally:

1. make sure you have Java 7+ SDK.  Must be the SDK and not JRE!
2. make a folder where you want grouper installed
3. run: java -jar grouperInstaller.jar
